// I used Cloud9 Night by default, apparently that's what Kai uses also
//monokai is decent
// jett is pretty good, thats what Ishan uses
// solarized dark is pretty nice also
// tomorrow night eighties is a bit more toned down but same as cloud9 night
// cobalt is interesting