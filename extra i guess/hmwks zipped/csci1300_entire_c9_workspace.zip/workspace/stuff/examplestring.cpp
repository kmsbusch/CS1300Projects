// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Homework 5 - Problem #1
#include <iostream>
using namespace std;

/*
Algorithm: 
Input parameters: 
Output (prints to screen): 
Returns: none
*/

int main()
{
    int number = 5;
    string sentence = "Today is Thursday";
    //string user_input;
    cout << sentence[0];
    char ch = sentence[6];
    
}