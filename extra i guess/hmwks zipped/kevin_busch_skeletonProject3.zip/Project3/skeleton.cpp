// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 

void characterCreate(string characterName)
{
    //player creates character here, called by start game func
    //sets values for money, influence, army size, location, ship.
}

string startGame(char yorn)
{
    //this function will initialize heroes and warriors, randomize dragonglass, randomize warrior locations
    //function will also update hero points by where they start
    //output greeting and ask name, input char goes here
    
    //big if statement for if player decides to input n and make their own character
    //if statement calls function characterCreate
}

string miniMap(int row, int column)
{
    //multiple ways to do this, first i will try is subtracting value from row & column to get to top left and then just cout next 7 symbols,
    //then change column and do the same until map is coutted. 
}

void turnFunc(int choice)
{
    //based on user input, functions from game class are called, such as movement, sleep, or consult
}

void encounterFunc(bool inRange)
{
    //based on user input, functions from game class are called, such as fight, buy, or speech
}

void warriorGet(bool inRange)
{
    // functions from hero class are called to obtain new warrior
}

void heroEncounter(bool inRange)
{
    //calculations for who wins in here
}

void tileCheck(char)
{
    //update values based on what tile user is on
}

int main()
{
    //first, filestream commands to open and read files
    //startGame func is called
    //map function is outputted based on starting location, then turn func is called
    
    //overarching if statement for if heroes are within proximity, encounter func is called
    // or maybe it is a function that is called at start and end of every turn
    
    //i think i need another function for obtaining nearby warriors
    // another function for hero encounters specifically
    //tile check function
    
    //functions for cities, random events, whitewalkers also necessary
}