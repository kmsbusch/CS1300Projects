// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Warrior.h"
using namespace std;

//
// 
// 
// 
// 
// 

Warrior::Warrior()
{
    string warriorName = "";
    int strength = 0;
    int loyalty = 0;
    int morale = 0;
    bool freedom = 0;
    bool ship = 0;
    bool dragonglass = 0;
}
Warrior::Warrior(string wName, int strongNum, int loyalNum, int happinessNum, bool freee, bool boat, bool dglass)
{
    string warriorName = wName;
    int strength = strongNum;
    int loyalty = loyalNum;
    int morale = happinessNum;
    bool freedom = freee;
    bool ship = boat;
    bool dragonglass = dglass;
}
void Warrior::setWarriorName(string wName)
{
    string warriorName = wName;
}
string Warrior::getWarriorName()
{
    return warriorName;
}
void Warrior::setStrength(int strongNum)
{
    int strength = strongNum;
}
int Warrior::getStrength()
{
    return strength;
}
void Warrior::setLoyalty(int loyalNum)
{
    int loyalty =  loyalNum;
}
int Warrior::getLoyalty()
{
    return loyalty;
}
void Warrior::setMorale(int happinessNum)
{
    int morale = happinessNum;
}
int Warrior::getMorale()
{
    return morale;
}
bool Warrior::freedom(bool yOrN)
{
    if (yOrN == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool Warrior::ship(bool yn)
{
    if (yn == true)
    {
        return true;
    }
    else
    {
        return false;
    } 
}
bool Warrior::dragonglass(bool dYOrN)
{
    if (dYOrN == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}

