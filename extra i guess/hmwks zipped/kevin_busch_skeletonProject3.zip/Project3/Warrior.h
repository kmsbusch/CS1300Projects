// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 

#ifndef WARRIOR_H
#define WARRIOR_H

class Warrior
{
public:
    Warrior();
    Warrior(string);
    void setWarriorName(string);
    string getWarriorName();
    void setStrength(int);
    int getStrength();
    void setLoyalty(int);
    int getLoyalty();
    void setMorale(int);
    int getMorale();
    bool freedom();
    bool ship();
    bool dragonglass();

private:
    string warriorName;
    int strength;
    int loyalty;
    int morale;
    bool freedom;
    bool ship;
    bool dragonglass;
    
    
};
#endif