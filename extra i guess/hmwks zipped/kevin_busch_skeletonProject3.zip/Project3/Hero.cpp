// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 
// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Hero.h"
using namespace std;

//
// 
// 
// 
// 
// 


Hero::Hero()
{
    heroName = "";
    money = 0;
    influence = 0;
    row = 0;
    column = 0;
}
Hero::Hero(string hName, int dollas, int influenceIn, int r, int c)
{
    heroName = hName;
    money = dollas;
    influence = influenceIn;
    row = r;
    column = c;
}
void Hero::setHeroName(string hName)
{
    heroName = hName;
}
int Hero::getHeroName()
{
    return heroName;
}
void Hero::setMoney(int dollas)
{
    money = dollas;
}
int Hero::getMoney()
{
    return money;
}
void Hero::setInfluence(int influenceIn)
{
    influence = influenceIn
}
int Hero::getInfluence()
{
    return influence;
}
void Hero::setWarrior(int index, string warriorName)
{
    //index is of an array of warriors 
    warriors[index] = warriorName;
    // this isn't exactly right, it'll change later 
}
int Hero::getWarrior(int index)
{
    return warriors[index];
}
void Hero::setRow(int rowNum)
{
    row = rowNum;
}
int Hero::getRow()
{
    return row;
}
void Hero::setColumn(int columnNum)
{
    column = columnNum
}
int Hero::getColumn()
{
    return column;    
}
bool Hero::ship(bool yn)
{
    bool ownShip;
    if (yn == true)
    {
        return true;
    }
    else
    {
        return false;
    }
}