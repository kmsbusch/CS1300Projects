// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "City.h"
using namespace std;

//
// 
// 
// 
// 
// 

City::City()
{
    string cityName = "";
    int money = 0;
    int influence = 0;
    int armySize = 0;
    char letter = "";
    int points = 0;
    int row = 0;
    int column = 0;

}
City::City(string)
{
    string cityName;
    int money;
    int influence;
    int armySize;
    char letter;
    int points;
    int row;
    int column;

}
void City::setCityName(string cName)
{
    string cityName = cName;
}
int City::getCityName()
{
    return cityName;
}
void City::setMoney(int dollas)
{
    int money = dollas;
}
int City::getMoney()
{
    return money;
}
void City::setLetter(char cLetter)
{
    char letter = cLetter;
}
int City::getLetter()
{
    return letter;
}
void City::setArmySize(int armyNum)
{
    int armySize = armyNum;
}
int City::getArmySize()
{
    return armySize;
}
void City::setPoints(int ptsIn)
{
    int points = ptsIn;
}
int City::getPoints()
{
    return points;
}
void City::setRow(int rowNum)
{
    int row = rowNum;
}
int City::getRow()
{
    return row;
}
void City::setColumn(int columnNum)
{
    int column = columnNum;
}
int City::getColumn()
{
    return column;
}


