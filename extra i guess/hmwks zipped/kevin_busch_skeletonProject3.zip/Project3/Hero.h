// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 
#ifndef HERO_H
#include HERO_H

class Hero
{
public:
    Hero();
    Hero(string, int, int, int, int);
    void setHeroName(string);
    int getHeroName();
    void setMoney(int);
    int getMoney();
    void setInfluence(int);
    int getInfluence();
    void setWarrior(int, string);
    int getWarrior(int);
    void setRow(int);
    int getRow();
    void setColumn(int);
    int getColumn();
    bool ship();
    
private:
    string hName;
    int money;
    int influence;
    int row;
    int column;
    Warrior warriors[4];
    
};
#endif
