// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 


// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 

#ifndef GAME_H
#include GAME_H

class Game
{
public:
    Game();//constructor
    Game(string);//constructor
    int diceRoll();//dice roll
    void movement(char);//direction player moves
    void therapyWithYeezus();//thereapy session with god
    void sleepChild();//rest time
    void fightBois();//beat em up
    void buyBois();//buy their loyalty
    void talkToEm();//convince them
    void endTurn();//end of turn
    void tileCheck();//check where the hero ends their turn
    void presetTurnCount();//preset events 
    void whiteWalkers();//whitewalkers
    void endGame();//game end

private:
    int turnCount;
    
};
#endif                                                                               