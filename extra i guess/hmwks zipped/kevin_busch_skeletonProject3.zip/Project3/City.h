// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

//
// 
// 
// 
// 
// 

#ifndef CITY_H
#include CITY_H

class City
{
public:
    City();
    City(string);
    void setCityName(string);
    int getCityName();
    void setMoney(int);
    int getMoney();
    void setLetter(char);
    int getLetter();
    void setArmySize(int);
    int getArmySize();
    void setPoints(int);
    int getPoints();
    void setRow(int);
    int getRow();
    void setColumn(int);
    int getColumn();
   
    
private:
    string cityName;
    int money;
    int influence;
    int armySize;
    char letter;
    int points;
    int row;
    int column;
    
};
#endif