// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://csci1300-kevinbusch.c9users.io
// Project 3
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Game.h"
using namespace std;

//
// 
// 
// 
// 
// 
    
Game::Game()//constructor
{
    int turncount = 0;
}
//not sure what to put in this
// Game::Game(string)//constructor
// {
    
// }


int Game::diceRoll()//dice roll
{
	return random() % 6 + 1;
}
void Game::movement(char)//direction player moves
{
    //choice to travel during turn
    //statements for not going on water or out of bounds
}
void Game::therapyWithYeezus()//thereapy session with god
{
    //doesn't move hero
    //increase party morale by one each
}
void Game::sleepChild()//rest time
{
    //location is same 
    //strength increase for each by 1
}
void Game::fightBois()//beat em up
{
    
}
void Game::buyBois()//buy their loyalty
void Game::talkToEm()//convince them
void Game::endTurn()//end of turn
//void Game::tileCheck()//check where the hero ends their turn
//not sure if tileCheck needs a class function or not but seems possibly unnecessary
void Game::presetTurnCount()//preset events 
void Game::whiteWalkers()//whitewalkers
void Game::endGame()//game end



