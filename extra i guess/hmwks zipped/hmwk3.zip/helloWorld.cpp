// CS1300 Spring 2019
// Author: Kevin Busch
// Recitation: 301 – Thanika Reddy
// Cloud9 Workspace Editor Link: https://ide.c9.io/kevinbusch/csci1300
// Homework 3 - Problem #1
#include <iostream>
using namespace std;
/*
Algorithm: output specific text to screen
Input: none
Output (prints to screen): "Hello, World!"
Returns: none
*/
int main()
{
    cout <<"Hello, World!" << endl;    
}

